# A Javascript Chatbot uilt with Gemini

A functional chatbot built with the Gemini AI

Link to the YouTube video: [Build and deploy your own ChatBot with Gemini (Complete Tutorial)🚀](https://youtu.be/1AJbhLBBPHU)
